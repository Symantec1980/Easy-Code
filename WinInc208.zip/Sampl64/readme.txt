
 In this directory are some samples showing how to use the WinInc
 include files for Win64.

 Name       comment
 ----------------------------------------------------------------------
 SEHSmpl    SEH sample
 SockHttp   reading a file via HTTP (sockets API)
 Toolhelp   toolhelp sample
 WinCon1    "hello world" Win64 console sample (native Win64)
 WinGui1    "hello world" Win64 GUI sample using a window
 WinUni1    "hello world" Win64 console sample with UNICODE support

 Please note that a NMake compatible make utility is used to build
 the samples. JWasm + JWlink [+ OW WRC] are the default tools to be used.
 The 64-bit version of Masm, ML64.exe, won't be able to assemble these
 samples.
