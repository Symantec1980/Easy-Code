
 This ODBC sample requires MS Access to be installed.
 The dataset which is read is supposed to be at ..\ADOSample\DB1.MDB.
 This can be changed by changing file DB1.DSN.


