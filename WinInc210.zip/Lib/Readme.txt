
if this directory is empty (or contains just UUID.LIB), view
..\Def\Readme.txt how to create the most important Win32 import libraries.
